package com.conamobile.pdpnotesapp.model

class Story(var date_notes:String, var name_notes:String) {

}