package com.conamobile.pdpnotesapp

import android.app.AlertDialog
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.conamobile.pdpnotesapp.adapter.NotesAdapter
import com.conamobile.pdpnotesapp.memory.MySharedPrefarance
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type


class MainActivity : AppCompatActivity() {

    lateinit var buttonAdd: FloatingActionButton
    lateinit var recyclerView: RecyclerView
    lateinit var recyclerViewAdapter: NotesAdapter
    var textList: ArrayList<String> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
    }

    override fun onStart() {
        super.onStart()
        if (MySharedPrefarance(this).getSavedList().toString() != ""){
        textList.add(MySharedPrefarance(this).getSavedList().toString())
        recyclerViewAdapter.notifyDataSetChanged()
        }
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, true)
        recyclerViewAdapter = NotesAdapter(this, textList)
        recyclerView.adapter = recyclerViewAdapter

        buttonAdd = findViewById(R.id.add_button)

        buttonAdd.setOnClickListener {
            showAlertDialog()
        }
    }

    private fun showAlertDialog() {
        val builder = AlertDialog.Builder(this, R.style.AlertDialogTheme)

        val view = LayoutInflater.from(this)
            .inflate(R.layout.customview_dialog, this.findViewById(R.id.layoutDialog))
        builder.setView(view)

        val alertDialog: AlertDialog = builder.create()

        view.findViewById<TextView>(R.id.cancel_btn).setOnClickListener {
            alertDialog.dismiss()
        }

        val editText = view.findViewById<EditText>(R.id.textMessage)

        view.findViewById<TextView>(R.id.save_btn).setOnClickListener {

            if (editText.text.toString() != "") {
                textList.add(editText.text.toString())
                alertDialog.dismiss()
                MySharedPrefarance(this).isSavedList(editText.text.toString())
                recyclerViewAdapter.notifyDataSetChanged()
                saveData()

            }
        }

        if (alertDialog.window != null) {
            alertDialog.window!!.setBackgroundDrawable(ColorDrawable(0))
        }

        alertDialog.setCancelable(true)

        alertDialog.show()
    }

    private fun saveData() {
        val sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE)

        val editor = sharedPreferences.edit()

        val gson = Gson()

        editor.apply()

        Toast.makeText(this, "Saved Array List to Shared preferences. ", Toast.LENGTH_SHORT).show()
    }
}